﻿using Microsoft.eShopOnContainers.BuildingBlocks.EventBus.Events;

namespace EventBus.Tests
{
    public record TestIntegrationEvent : IntegrationEvent
    {
    }
}
