﻿namespace Microsoft.eShopOnContainers.Services.Identity.API.Models.AccountViewModels
{
    public class RedirectViewModel
    {
        public string RedirectUrl { get; set; }
    }
}